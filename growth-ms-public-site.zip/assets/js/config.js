window.GROWTH_CONFIG = Object.freeze({
  "SUPPORT_EMAIL": "support@growthms.dev",
  "PRODUCT_PRICE": 79,
  "CURRENCY": "USD",
  "SITE_URL": "https://growthms.dev",
  "PRODUCT_URL": "https://growthms.dev/solo-business-os/",
  "STRIPE_CHECKOUT_URL": "",
  "META_PIXEL_ID": "",
  "ANALYTICS_ENABLED": false
});
